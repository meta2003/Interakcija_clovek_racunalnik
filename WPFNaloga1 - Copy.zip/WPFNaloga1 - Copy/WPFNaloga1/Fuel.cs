﻿namespace WPFNaloga1
{
    public enum Fuel
    {
        Bencin,
        Dizel,
        Elektrika
    }
}
